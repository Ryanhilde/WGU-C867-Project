#pragma once
#include "softwareStudent.h"
#include "networkStudent.h"
#include "securityStudent.h"

class Roster {
public:

	Roster();
	virtual ~Roster();
	Student *classRosterArray[5] = { nullptr, nullptr, nullptr, nullptr, nullptr };

	void Add(string ID, string First, string Last, string EmailAddress, int setAge, int numDays0, int numDays1, int numDays2, Degree);
	void Remove(string studentID);
	void PrintAll();
	void PrintDaysInCourse(string studentID);
	void PrintInvalidEmails();
};