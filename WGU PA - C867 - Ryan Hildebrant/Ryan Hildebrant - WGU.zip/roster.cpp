#include <iostream>
#include <string>
#include <sstream>
#include <cstring>
#include <vector>
#include "roster.h"

using namespace std;

Roster::Roster() {}



void main() {

	cout << "C867 - Scripting and Programming-Applications" << endl;
	cout << "Written in C++" << endl;
	cout << "Student ID #: 000709587 - Ryan Hildebrant" << endl;
	

	string studentData[5] = {
	"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
	"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
	"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
	"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
	"A5,Ryan,Hildebrant,rhilde2@wgu.edu,23,43,31,13,SOFTWARE,"
	};

	/*string s;
	int i = 0;
	string studentArray[5][9];
	
	for (i = 0; i < 5; i++) {

		s = studentData[i];
		int a = 0;
		//break as up into it's tokens - meaning: break into "A1","John"...etc.
		string delimiter = ",";
		int pos = 0;
		string token;
		while ((pos = s.find(delimiter)) != string::npos) {
			token = s.substr(0, pos);
			studentArray[i][a] = token; 
			a++;
			s.erase(0, pos + delimiter.length());
		}
		
		cout << "STUDENT RECORD" << endl;
		for (int j = 0; j < 9; j++) {
			cout << studentArray[i][j] << " ";
			
		}
		cout << endl << endl;*/
	//Create Roster
	Roster classRoster;
	//Create Degree
	Degree degreeObject;
	for (int i = 0; i < sizeof(studentData) / sizeof(studentData[i]); i++) {
		
		string input = studentData[i];
		istringstream ss(input);
		string token;
		string holderArray[9];

		int x = 0;
		while (getline(ss, token, ',')) {
			holderArray[x] = token;
			x += 1;
		}
		if (holderArray[8] == "SECURITY") {
			degreeObject = Degree::SECURITY;
		}
		else if (holderArray[8] == "SOFTWARE") {
			degreeObject = Degree::SOFTWARE;
		}
		else if (holderArray[8] == "NETWORK") {
			degreeObject = Degree::NETWORKING;
		}
		classRoster.Add(holderArray[0], holderArray[1], holderArray[2], holderArray[3], stoi(holderArray[4]), stoi(holderArray[5]),
			stoi(holderArray[6]), stoi(holderArray[7]), degreeObject);
	
	}



	system("pause");
}
//Used to update classRosterArray
void Roster::Add(string ID, string First, string Last, string EmailAddress, int setAge, int numDays0, int numDays1, int numDays2, Degree degProg)
{
	int averageCourseDays[3] = { numDays0, numDays1, numDays2 };

	for (int i = 0; i < sizeof(classRosterArray) / sizeof(classRosterArray[i]); i++) {
		if (classRosterArray[i] == nullptr) {
			if (degProg == NETWORKING) {
				classRosterArray[i] = new NetworkStudent(ID, First, Last, EmailAddress, setAge, averageCourseDays, degProg);
			}
			else if (degProg == SECURITY) {
				classRosterArray[i] = new SecurityStudent(ID, First, Last, EmailAddress, setAge, averageCourseDays, degProg);
			}
			else if (degProg == SOFTWARE) {
				classRosterArray[i] = new SoftwareStudent(ID, First, Last, EmailAddress, setAge, averageCourseDays, degProg);
			}
			/*else {
				classRosterArray[i] = new Student(ID, First, Last, EmailAddress, setAge, averageCourseDays, degProg);
			}*/

			break;
		}
	}
}

Roster::~Roster() {}

