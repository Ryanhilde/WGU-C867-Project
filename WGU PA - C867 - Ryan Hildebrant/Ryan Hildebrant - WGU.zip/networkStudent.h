#pragma once
#include "student.h"

class NetworkStudent : public Student {
private:
	Degree degProg;
public:
	NetworkStudent();
	NetworkStudent(string, string, string, string, int, int*, Degree);
	Degree getDegree();
	//Degree getDegree() override;
	//void Print() override;



};