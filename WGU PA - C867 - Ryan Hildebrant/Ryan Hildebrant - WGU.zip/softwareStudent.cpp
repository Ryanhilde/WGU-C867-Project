#include <iostream>
#include <string>
#include "softwareStudent.h"

SoftwareStudent::SoftwareStudent() {}

SoftwareStudent::SoftwareStudent(string ID, string First, string Last, string emailAddress, int setAge, int *numDays, Degree studentDegree) : Student(ID, First, Last, emailAddress, setAge, numDays) {

	degProg = studentDegree;
}

Degree SoftwareStudent::getDegreeProgram()
{
	return Degree();
}