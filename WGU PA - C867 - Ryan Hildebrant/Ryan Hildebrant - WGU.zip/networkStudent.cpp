#include <iostream>
#include "networkStudent.h"

NetworkStudent::NetworkStudent() {}

NetworkStudent::NetworkStudent(string ID, string First, string Last, string emailAddress, int setAge, int *numDays, Degree studentDegree) : Student(ID, First, Last, emailAddress, setAge, numDays) {

	degProg = studentDegree;
}

Degree NetworkStudent::getDegree() {

	return degProg;
}


