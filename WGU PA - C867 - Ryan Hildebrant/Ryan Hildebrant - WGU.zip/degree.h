#pragma once

using namespace std;

enum Degree {SECURITY, NETWORKING, SOFTWARE};

